package Collections;

public interface comercializarInterface {
    public static void comercializa(){
        
    }
}
